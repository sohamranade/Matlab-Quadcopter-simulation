function [F, M] = controller(t, state, des_state, params)
%CONTROLLER  Controller for the quadrotor
%
%   state: The current state of the robot with the following fields:
%   state.pos = [x; y; z], state.vel = [x_dot; y_dot; z_dot],
%   state.rot = [phi; theta; psi], state.omega = [p; q; r]
%
%   des_state: The desired states are:
%   des_state.pos = [x; y; z], des_state.vel = [x_dot; y_dot; z_dot],
%   des_state.acc = [x_ddot; y_ddot; z_ddot], des_state.yaw,
%   des_state.yawdot
%
%   params: robot parameters

%parameters are 12 Kp for all the angles as well as for the states

%defining those parameters
noiseP= 0.1*sin(1000*t);
noiseV= 0.1*sin(1000*t);
noiseA= 0.1*sin(1000*t);

state.pos=state.pos+noiseP;
state.vel=state.vel+noiseV;
des_state.omega=[0;0;des_state.yawdot];
kp_phi=350;kd_phi=40;
kp_psi=60; kd_psi=8;
kp_theta=350; kd_theta=40;
kp_x=17; kd_x=16;
kp_y=17; kd_y=16;
kp_z=100; kd_z=65;
Rot=[sin(des_state.yaw) -cos(des_state.yaw) 0;
    cos(des_state.yaw) sin(des_state.yaw) 0;
    0 0 0];
%params defined

err_pos=des_state.pos-state.pos;
err_vel=des_state.vel-state.vel;
%errors defined for the controller basically for the position controller

acc_des=des_state.acc +[kp_x 0 0; 0 kp_y 0;0 0 kp_z]*err_pos +[kd_x 0 0; 0 kd_y 0;0 0 kd_z ]*err_vel;%defining the controller for x and y intermediate for attitude controller
ang_des= (Rot*acc_des)/params.gravity; 
ang_des(3,1)=des_state.yaw;
%you found the desired angles now


%substitute the same to find error and then u2

err_ang=ang_des-state.rot;
err_angv= des_state.omega-state.omega;

F=[0;0;params.mass*params.gravity] + params.mass*acc_des;
F=F(3,1);
u2=[kp_phi 0 0; 0 kp_theta 0;0 0 kp_psi]*err_ang + [kd_phi 0 0; 0 kd_theta 0;0 0 kd_psi]*err_angv;
M=params.I*u2;
% =================== Your code ends here ===================

end
