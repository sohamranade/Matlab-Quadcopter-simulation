function [coeff]=findCoeff(waypoints)
 %function takes in waypoints to give appropriate coeffs. 
n =size(waypoints,2)-1;
A=zeros(8*n,8*n);
b=zeros(8*n,3);
waypoints=waypoints';
%handling the first 2n conditions
for i=1:n
    A(2*i-1,8*(i-1)+1:8*(i))=polyT(8,0,0);
    A(2*i,8*(i-1)+1:8*(i))=polyT(8,0,1);
    b(2*i-1:2*i,1:3)=waypoints(i:i+1,1:3);
    %first 2n conditions implemented
end
% 6(n-1)conditions implemented
k=2*n;
for j=1:6
    for i=1:n-1
        A(k+i,8*(i-1)+1:8*i)=polyT(8,j,1);
        A(k+i,8*(i)+1:8*(i+1))=-1*(polyT(8,j,1));
    end
    k=k+n-1;
end
%implementing first and final conditions
p=k+1;
for j=1:3
    A(p,1:8)=polyT(8,j,0);
    A(p+1,8*(n-1)+1:8*n)=polyT(8,j,1);
    p=p+2;
end
coeff=A\b;
%getting coeff for the splines in x,y,z order.
end