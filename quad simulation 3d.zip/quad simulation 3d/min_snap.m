persistent waypoints_p trajTime coeff t0 
if nargin > 2
     waypoints_p =waypoints;
     coeff=findCoeff(waypoints_p);
     d = waypoints(:,2:end) - waypoints(:,1:end-1);
     t0 = sqrt(d(1,:).^2 + d(2,:).^2 + d(3,:).^2);
     trajTime = [0, cumsum(t0)];
else
     if t>trajTime(end)
         t=trajTime(end);
     end
     traj_index=find(trajTime>=t,1)-1;
     if traj_index==0
         traj_index=traj_index+1;
         
         desired_state.pos=(polyT(8,0,0)*coeff(8*(traj_index-1)+1:8*(traj_index),:))';
         desired_state.vel=(polyT(8,1,0)*coeff(8*(traj_index-1)+1:8*(traj_index),:))';
         desired_state.acc=(polyT(8,2,0)*coeff(8*(traj_index-1)+1:8*(traj_index),:))';
         desired_state.yaw=0;
         desired_state.yawdot=0;
     else
         t=t-trajTime(traj_index);
         t=t/t0(traj_index);
         desired_state.pos=(polyT(8,0,t)*coeff(8*(traj_index-1)+1:8*(traj_index),:))';
         desired_state.vel=(polyT(8,1,t)*coeff(8*(traj_index-1)+1:8*(traj_index),:))';
         desired_state.acc=(polyT(8,2,t)*coeff(8*(traj_index-1)+1:8*(traj_index),:))';
         desired_state.yaw=0;
         desired_state.yawdot=0;
     end
end