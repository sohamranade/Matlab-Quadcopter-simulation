omega=[0;0;desYawdot];
kp_phi=350;kd_phi=40;
kp_psi=60; kd_psi=8;
kp_theta=350; kd_theta=40;
kp_x=17; kd_x=16;
kp_y=17; kd_y=16;
kp_z=400; kd_z=40;
Rot=[sin(desYaw) -cos(desYaw) 0;
    cos(desYaw) sin(desYaw) 0;
    0 0 0];
%params defined


err_pos=desPos-Xe;
err_vel=desvel-Ve;
%errors defined for the controller basically for the position controller

acc_des=desaccn +[kp_x 0 0; 0 kp_y 0;0 0 kp_z]*err_pos +[kd_x 0 0; 0 kd_y 0;0 0 kd_z ]*err_vel;%defining the controller for x and y intermediate for attitude controller
ang_des= (Rot*acc_des)/mg(2); 
ang_des(3,1)=desYaw;
%you found the desired angles now

%substitute the same to find error and then u2

err_ang=ang_des-rot;
err_angv=omega-rotvel;

F=[0;0;mg(1)*mg(2)] + mg(1)*acc_des;
F=F(3,1);
u2=[kp_phi 0 0; 0 kp_theta 0;0 0 kp_psi]*err_ang + [kd_phi 0 0; 0 kd_theta 0;0 0 kd_psi]*err_angv;
M=inertia*u2;